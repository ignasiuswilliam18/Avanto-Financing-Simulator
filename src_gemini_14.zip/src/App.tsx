import React, { useState, useMemo } from 'react';

// Data Dropdown (Bisa Anda tarik langsung dari data Excel)
const HP_OPTIONS = [
  { model: "OPPO Reno13 F 4G 8+256", harga: 4499000 },
  { model: "OPPO Reno15 5G 8+256", harga: 9299000 },
];
const IOT_OPTIONS = [
  { model: "Non Bundling", harga: 0 },
  { model: "OPPO AIRVOOC 50W", harga: 999000 },
];
const CARE_OPTIONS = [
  { model: "Non Bundling", harga: 0 },
  { model: "OPPO CARE A SERIES", harga: 299000 },
  { model: "OPPO CARE RENO SERIES", harga: 799000 },
];

const App: React.FC = () => {
  const [hp, setHp] = useState(HP_OPTIONS[0]);
  const [iot, setIot] = useState(IOT_OPTIONS[0]);
  const [care, setCare] = useState(CARE_OPTIONS[0]);
  const [tenor, setTenor] = useState(9);

  // Fungsi Kalkulasi sesuai Formula Excel: ((G+G*2%)+(G+G*2%)*Bunga*Tenor)/Tenor
  const calculate = (totalBarang: number) => {
    const admin = totalBarang * 0.02;
    const pokokPlusAdmin = totalBarang + admin;
    const bungaRate = 0.0375; // Contoh 3.75%, sesuaikan dengan tenor di Excel
    const totalPengembalian = pokokPlusAdmin + (pokokPlusAdmin * bungaRate * tenor);
    return {
      cicilan: Math.round(totalPengembalian / tenor),
      admin,
      totalPengembalian: Math.round(totalPengembalian)
    };
  };

  const ops1 = useMemo(() => calculate(hp.harga), [hp, tenor]);
  const ops2 = useMemo(() => calculate(hp.harga + iot.harga + care.harga), [hp, iot, care, tenor]);

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-xl font-bold text-green-700 mb-6">AVANTO PROMOTOR SMART BUNDLE SIMULATOR</h1>
      
      <div className="grid grid-cols-2 gap-8">
        {/* PANEL KIRI: DROPDOWN INPUT */}
        <div className="space-y-4">
          <label className="block font-bold">2. PILIH TIPE HP OPPO</label>
          <select className="w-full p-2 border rounded" onChange={(e) => setHp(JSON.parse(e.target.value))}>
            {HP_OPTIONS.map(i => <option key={i.model} value={JSON.stringify(i)}>{i.model}</option>)}
          </select>

          <label className="block font-bold">3. TAMBAH PROTEKSI OPPO CARE</label>
          <select className="w-full p-2 border rounded" onChange={(e) => setCare(JSON.parse(e.target.value))}>
            {CARE_OPTIONS.map(i => <option key={i.model} value={JSON.stringify(i)}>{i.model}</option>)}
          </select>

          <label className="block font-bold">4. TAMBAH PRODUK IOT</label>
          <select className="w-full p-2 border rounded" onChange={(e) => setIot(JSON.parse(e.target.value))}>
            {IOT_OPTIONS.map(i => <option key={i.model} value={JSON.stringify(i)}>{i.model}</option>)}
          </select>
        </div>

        {/* PANEL KANAN: HASIL SIMULASI */}
        <div className="border p-4 rounded-lg bg-gray-50">
          <h2 className="font-bold text-green-700">Skema Pembiayaan ({tenor} Bulan)</h2>
          <div className="grid grid-cols-2 gap-4 my-4">
            <div className="p-3 border rounded bg-white">
              <p className="text-xs">OPSI 1 (HP Saja)</p>
              <p className="text-lg font-bold">Rp {ops1.cicilan.toLocaleString()}</p>
            </div>
            <div className="p-3 border-2 border-green-500 rounded bg-green-50">
              <p className="text-xs">OPSI 2 (Paket Lengkap)</p>
              <p className="text-lg font-bold">Rp {ops2.cicilan.toLocaleString()}</p>
            </div>
          </div>
          <div className="text-sm border-t pt-2">
            <p>Selisih Angsuran: <strong>+ Rp {(ops2.cicilan - ops1.cicilan).toLocaleString()} / bln</strong></p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;